<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        input[type="checkbox"] {
            transform: scale(1.5);
            margin-right: 5px;
        }


    </style>


    <div class="content-wrapper">
        <div class="card">
            <div style="margin-top: 10px;" class="card-header">
                <h3>User Rights</h3>
                <a href="<?php echo e(route('user-options.create')); ?>">
                    <button class="btn btn-success float-right">Add User</button>
                </a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Group</th>
                        <th>Status</th>
                        <th>Options</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user_option['id']); ?></td>
                            <td><?php echo e($user_option['user']['name'] ?? ''); ?></td>
                            <td><?php echo e($user_option['user']['email'] ?? ''); ?></td>
                            <td><?php echo e($user_option['role']['name'] ?? ''); ?></td>
                            <td><?php echo e($user_option['status'] ?? ''); ?></td>
                            <td><div class="row">
                                    <a href="#" onclick="setModalData(<?php echo e($user_option['id']); ?>,<?php echo json_encode($user_option['user_rights']->pluck('id')->toArray()); ?>)" data-toggle="modal" data-target="#exampleModal">
                                        <i style="color: green;" class="col fa fa-list-ol"></i>
                                    </a>
                                    <a href="<?php echo e(route('user-options.edit', $user_option['id'])); ?>">
                                        <i style="color: green;" class="col far fa-edit"></i>
                                    </a>
                                    
                                    
                                    
                                </div></td>
                        </tr>
                        <div class="modal fade" id="modal-danger">
                            <div class="modal-dialog">
                                <div class="modal-content bg-danger">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Delete</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <p>Are you sure you want to delete this?</p>
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                        <form method="POST" action="<?php echo e(route('user-options.destroy', $user_option['id'])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('Delete'); ?>
                                            <button type="submit" class="float-left btn btn-outline-light">Delete</button>
                                        </form>
                                        <button type="button" class="btn btn-outline-light" data-dismiss="modal">Cancel</button>
                                    </div>
                                </div>
                                <!-- /.modal-content -->
                            </div>
                            <!-- /.modal-dialog -->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 id="heading"></h2>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form id="rightsForm" method="POST" action="">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <table>
                                    <thead>
                                    <tr>
                                        <th>Right</th>
                                        <th>Module</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="checkbox" name="module_ids[]" value="<?php echo e($module->id); ?>">
                                            </td>
                                            <td><?php echo e($module->name); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
    </div>

</div>

<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page specific script -->
<script>
    $(function () {
        $("#example1").DataTable({
            "lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
            "order": [[ 0, "desc" ]],
            "responsive": true, "lengthChange": true, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    function setModalData(userId, userRights) {
        var form = document.getElementById('rightsForm');
        form.action = "<?php echo e(url('/user-rights/')); ?>" + '/' + userId;

        var checkboxes = document.getElementsByName('module_ids[]');
        checkboxes.forEach(function (checkbox) {
            checkbox.checked = userRights.includes(parseInt(checkbox.value));
        });
    }

</script>
</body>
</html>
