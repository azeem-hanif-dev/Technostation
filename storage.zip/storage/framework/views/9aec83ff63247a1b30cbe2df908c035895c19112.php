
<meta charset="utf-8">
  <title>DCS - Digital Cleaning Solution</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicon -->
  <link href="public/new_landing_page/img/favicon.ico" rel="icon">

  <!-- Google Web Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">

  <!-- Icon Font Stylesheet -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

  <!-- Libraries Stylesheet -->
  <link href="<?php echo e(asset('new_landing_page/lib/animate/animate.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('new_landing_page/lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">

  <!-- Customized Bootstrap Stylesheet -->
  <link href="<?php echo e(asset('new_landing_page/css/bootstrap.min.css')); ?>" rel="stylesheet">

  <!-- Template Stylesheet -->
  <link href="<?php echo e(asset('new_landing_page/css/style.css')); ?>" rel="stylesheet">

  <link href="<?php echo e(asset('new_landing_page/slider/css/new.css')); ?>" rel="stylesheet">

  <script>
    var APP_URL = <?php echo json_encode(url('/').'/'); ?>

  </script>
<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
