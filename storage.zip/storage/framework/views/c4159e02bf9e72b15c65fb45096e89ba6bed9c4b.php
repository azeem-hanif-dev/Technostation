<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
        <div id="myapp">
            <create-contact
                :translations="<?php echo e(json_encode($translations)); ?>"
                :departments="<?php echo e(json_encode($departments)); ?>">
            </create-contact>
        </div>
    </div>

</div>
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
