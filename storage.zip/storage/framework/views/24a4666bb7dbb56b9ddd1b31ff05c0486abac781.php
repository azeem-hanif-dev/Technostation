<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="content-wrapper">
        <div class="card">
            <div style="margin-top: 10px;" class="card-header">
                <div class="row">
                    <div class="col-md-6">
                        <h3><?php echo e(__('Staffing_Company/Container_Supplier/c_index.container_supplier')); ?></h3>
                    </div>
                    <div class="col-md-6">
                        <a href="<?php echo e(route('container-supplier.create')); ?>">
                            <button class="btn btn-success float-right"><?php echo e(__('Staffing_Company/Container_Supplier/c_index.new_supplier')); ?></button>
                        </a>
                    </div>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th><?php echo e(__('Staffing_Company/Container_Supplier/c_index.company_name')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Container_Supplier/c_index.code')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.address')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.telephone')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.email')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.option')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($supplier->company_name ?? ''); ?></td>
                            <td><?php echo e($supplier->code ?? ''); ?></td>
                            <td><?php echo e($supplier->address ?? ''); ?></td>
                            <td><?php echo e($supplier->telephone ?? ''); ?></td>
                            <td><?php echo e($supplier->email ?? ''); ?></td>
                            <td><div class="row">
                                    <a href="<?php echo e(route('container-supplier.view', $supplier->id)); ?>">
                                        <i style="color: green;" class="col fa fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('container-supplier.edit', $supplier->id)); ?>">
                                        <i style="color: green;" class="col far fa-edit"></i>
                                    </a>
                                    <form method="POST" action="<?php echo e(route('container-supplier.destroy', $supplier->id)); ?>" id="delete-form-<?php echo e($supplier->id); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('Delete'); ?>
                                        <i style="color: red" type="button" onclick="confirmDelete(<?php echo e($supplier->id); ?>)" class="col fas fa-trash"></i>
                                    </form>
                                </div></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
    </div>

</div>

<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page specific script -->
<script>
    $(function () {
        $("#example1").DataTable({
            "lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
            "order": [[ 0, "desc" ]],
            "responsive": true, "lengthChange": true, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    function confirmDelete(itemId) {
        if (confirm('Are you sure you want to delete this?')) {
            document.getElementById('delete-form-' + itemId).submit();
        }
    }
</script>
</body>
</html>
