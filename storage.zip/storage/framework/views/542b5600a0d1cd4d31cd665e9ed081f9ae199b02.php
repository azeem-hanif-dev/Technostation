<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="content-wrapper">
        <div class="card">
            <div style="margin-top: 10px;" class="card-header">
                <h3><?php echo e(__('Staffing_Company/Staff_Function/f_index.staff_function')); ?></h3>
                <a href="<?php echo e(route('employee_functions.create')); ?>">
                    <button class="btn btn-success float-right"><?php echo e(__('Staffing_Company/Staff_Function/f_index.add_new')); ?></button>
                </a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th><?php echo e(__('Staffing_Company/Staff_Function/f_index.id')); ?>.#</th>
                        <th><?php echo e(__('Staffing_Company/Staff_Function/f_index.name')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Staff_Function/f_index.code')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Staff_Function/f_index.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $employee_functions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee_function): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($employee_function->id); ?></td>
                            <td><?php echo e($employee_function->name ?? ''); ?></td>
                            <td><?php echo e($employee_function->code ?? ''); ?></td>
                            <td><div class="row">
                                    <a href="<?php echo e(route('employee-functions.show',$employee_function->id )); ?>">
                                        <i style="color: green;" class="col fa fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('employee_functions.edit', $employee_function->id)); ?>">
                                        <i style="color: green;" class="col far fa-edit"></i>
                                    </a>





                                </div></td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
    </div>

</div>

<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page specific script -->
<script>
    $(function () {
        $("#example1").DataTable({
            "lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
            "order": [[ 0, "desc" ]],
            "responsive": true, "lengthChange": true, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    function confirmDelete(itemId) {
        if (confirm('Are you sure you want to delete this?')) {
            document.getElementById('delete-form-' + itemId).submit();
        }
    }
</script>
</body>
</html>
