<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="content-wrapper">
        <div class="card">
            <div style="margin-top: 10px;" class="card-header">
                <div class="row">
                    <div class="col-md-6">
                        <h3><?php echo e(__('Staffing_Company/Order_Container/o_index.order_waste')); ?></h3>
                    </div>
                    <div class="col-md-6">
                        <a href="<?php echo e(route('order-waste-container.create')); ?>">
                            <button class="btn btn-success float-right"><?php echo e(__('Staffing_Company/Order_Container/o_index.new_order')); ?></button>
                        </a>
                    </div>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th><?php echo e(__('Staffing_Company/Order_Container/o_index.order')); ?>#</th>
                        <th><?php echo e(__('Staffing_Company/Order_Container/o_index.order_date')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Order_Container/o_index.execution_date')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Order_Container/o_index.customer_name')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Order_Container/o_index.project_name')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Order_Container/o_index.waste_process')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Order_Container/o_index.sent')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.status')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.option')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $order_containers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_container): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($order_container->id); ?></td>
                            <td>BN-<?php echo e($order_container->id ?? ''); ?></td>
                            <td><?php echo e($order_container->order_date_time ?? ''); ?></td>
                            <td><?php echo e($order_container->execution_date ?? ''); ?></td>
                            <td><?php echo e($order_container->order_by ?? ''); ?></td>
                            <td><?php echo e($order_container->project->name ?? ''); ?></td>
                            <td><?php echo e($order_container->supplier->company_name ?? ''); ?></td>
                            <td><span style="color: white; padding: 3px; font-size: 12px; background-color: green"><?php echo e(__('Staffing_Company/Order_Container/o_index.sent')); ?></span></td>
                            <td><span style="color: white; padding: 3px; font-size: 12px; background-color: green"><?php echo e(__('Staffing_Company/Order_Container/o_index.order')); ?></span></td>
                            <td><div class="row">
                                    <a href="<?php echo e(route('order-container.view', $order_container->id)); ?>">
                                        <i style="color: green;" class="col fa fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('order-waste-container.edit', $order_container->id)); ?>">
                                        <i style="color: green;" class="col far fa-edit"></i>
                                    </a>
                                    <form method="POST" action="<?php echo e(route('order-waste-container.destroy', $order_container->id)); ?>" id="delete-form-<?php echo e($order_container->id); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('Delete'); ?>
                                        <i style="color: red" type="button" onclick="confirmDelete(<?php echo e($order_container->id); ?>)" class="col fas fa-trash"></i>
                                    </form>
                                </div></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
    </div>

</div>

<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page specific script -->
<script>
    $(function () {
        $("#example1").DataTable({
            "lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
            "order": [[ 0, "desc" ]],
            "responsive": true, "lengthChange": true, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    function confirmDelete(itemId) {
        if (confirm('Are you sure you want to delete this?')) {
            document.getElementById('delete-form-' + itemId).submit();
        }
    }
</script>
</body>
</html>
