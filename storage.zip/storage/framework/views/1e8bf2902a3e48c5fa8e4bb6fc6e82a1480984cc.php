<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="content-wrapper">
        <div class="card">
            <div style="margin-top: 10px;" class="card-header">
                <h3><?php echo e(__('Staffing_Company/staff/s_index.staff')); ?></h3>
                <a href="<?php echo e(route('personnels.create')); ?>">
                    <button class="btn btn-success float-right"><?php echo e(__('Staffing_Company/staff/s_index.add_new')); ?></button>
                </a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th><?php echo e(__('Staffing_Company/staff/s_index.first_name')); ?></th>
                        <th><?php echo e(__('Staffing_Company/staff/s_index.last_name')); ?></th>
                        <th><?php echo e(__('Staffing_Company/staff/s_index.bsn')); ?></th>
                        <th><?php echo e(__('Staffing_Company/staff/s_index.emp_agency')); ?></th>
                        <th>Online</th>
                        <th><?php echo e(__('Staffing_Company/staff/s_index.job')); ?></th>
                        <th><?php echo e(__('Staffing_Company/staff/s_index.option')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $personnels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personnel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($personnel->id); ?></td>
                            <td><?php echo e($personnel->first_name ?? ''); ?></td>
                            <td><?php echo e($personnel->last_name ?? ''); ?></td>
                            <td><?php echo e($personnel->social_security_number ?? ''); ?></td>
                            <td><?php echo e($personnel->agency->name ?? ''); ?></td>


                            <?php if($personnel->user): ?>
                                
                                <?php if($personnel->user->loggedIn!=Null): ?>
                                <td style="text-align: center"><p id="last-seen-online-<?php echo e($personnel->id); ?>" data-last-logged-in="<?php echo e($personnel->user->lastLoggedIn); ?>"></p></td>
                                <?php else: ?>
                                    <td style="text-align: center"><small>🔴</small></td>
                                <?php endif; ?>
                            <?php else: ?>
                                <td style="text-align: center"><small>🔴</small></td>  <!-- Display a default value or message if user relation doesn't exist -->
                            <?php endif; ?>


                            <td style="text-align: center"><?php if($personnel->active): ?>
                                    <span style="color: white; padding: 3px; font-size: 12px; background-color: green"><?php echo e(__('Staffing_Company/staff/s_index.active')); ?></span>
                                <?php else: ?>
                                    <span style="color: white; padding: 3px; font-size: 12px; background-color: red"><?php echo e(__('Staffing_Company/staff/s_index.inactive')); ?></span>
                                <?php endif; ?></td>
                            <td><div class="row">
                                    <a href="<?php echo e(route('employee-history', $personnel->id)); ?>">
                                        <i style="color: green;" class="col fa fa-history"></i>
                                    </a>
                                    <a href="<?php echo e(route('personnels.show', $personnel->id)); ?>">
                                        <i style="color: green;" class="col fa fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('personnels.edit', $personnel->id)); ?>">
                                        <i style="color: green;" class="col far fa-edit"></i>
                                    </a>
                                    <form method="POST" action="<?php echo e(route('personnels.destroy', $personnel->id)); ?>" id="delete-form-<?php echo e($personnel->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('Delete'); ?>
                                        <i style="color: red" type="button" onclick="confirmDelete(<?php echo e($personnel->id); ?>)" class="col fas fa-trash"></i>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
    </div>

</div>

<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page specific script -->
<script>
    $(function () {
        $("#example1").DataTable({
            "lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
            //"order": [[ 0, "desc" ]],
            "order":[],
            "responsive": true, "lengthChange": true, "autoWidth": false,"ordering": true,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"],
          
        
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    function confirmDelete(itemId) {
        if (confirm('Are you sure you want to delete this?')) {
            document.getElementById('delete-form-' + itemId).submit();
        }
    }
    
    // Online Functionality
   /// RUN AFTER DATATABLE IS LOADED but sorting is lost
//     $("#example1").on('draw.dt', function() {
//     // Get all elements with the data-last-logged-in attribute
//     const elements = document.querySelectorAll('[data-last-logged-in]');

//     console.log('xxx', elements.length);

//     // Loop through each element and calculate the time difference
//     elements.forEach(element => {
//         calculateTimeDifference(element);
//     });
// })

    function calculateTimeDifference(element) {
        const lastLoggedIn = element.getAttribute('data-last-logged-in');

        if (lastLoggedIn !== '') {
            const lastLoggedInDate = new Date(lastLoggedIn);

            // Get current time in Netherlands
            const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'Europe/Amsterdam' }));
            
            const timeDiff = now - lastLoggedInDate;
            const timeDiffHours = Math.floor(timeDiff / 3600000);

            if (timeDiffHours > 168) {
                element.innerHTML = '<small>🔴</small>';
            } else if (timeDiffHours > 8) {
                element.innerHTML = `<small>${timeDiffHours}h 🔴</small>`;
            } else {
                element.innerHTML = `<small>${timeDiffHours}h 🟢</small>`;
            }
        } else {
            element.innerHTML = '<small>🔴</small>';
        }
    }
    const elements = document.querySelectorAll('[data-last-logged-in]');

    console.log('xxx', elements.length);

    // Loop through each element and calculate the time difference
    elements.forEach(element => {
        calculateTimeDifference(element);
    });

    

</script>
</body>
</html>
