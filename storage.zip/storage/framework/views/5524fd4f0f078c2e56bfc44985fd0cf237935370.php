<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> | <?php echo e(config('app.name', 'DCS')); ?></title>
    <?php echo $__env->make('StaffingCompany.partials._styles', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
</head>
<script>
      var APP_URL = <?php echo json_encode(url('/').'/'); ?>

</script>
<script>
    window.auth = <?php echo auth()->user(); ?>

</script>
