<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="content-wrapper">
        <div class="card">
            <h3><?php echo e(__('Staffing_Company/Agency/a_index.ea')); ?></h3>
            <div style="margin-top: 10px;" class="card-header">
                <a href="<?php echo e(route('employment-agencies.create')); ?>">
                    <button class="btn btn-success float-right"><?php echo e(__('Staffing_Company/Agency/a_index.add_new_ea')); ?></button>
                </a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th><?php echo e(__('Staffing_Company/common.name')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.email')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Agency/a_index.company')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.phone')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.address')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($agency->id); ?></td>
                            <td><?php echo e($agency->name ?? ''); ?></td>
                            <td><?php echo e($agency->email ?? ''); ?></td>
                            <td><?php echo e($agency->company->name ?? ''); ?></td>
                            <td><?php echo e(_formatPhoneNumber($agency->phone) ?? ''); ?></td>
                            <td><?php echo e($agency->address ?? ''); ?></td>
                            <td><div class="row">
                                    <a href="<?php echo e(route('employment-agency.view', $agency->id)); ?>">
                                        <i style="color: green;" class="col fa fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('employment-agencies.edit', $agency->id)); ?>">
                                        <i style="color: green;" class="col far fa-edit"></i>
                                    </a>
                                    <form method="POST" action="<?php echo e(route('employment-agencies.destroy', $agency->id)); ?>" id="delete-form-<?php echo e($agency->id); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('Delete'); ?>
                                        <i style="color: red" type="button" onclick="confirmDelete(<?php echo e($agency->id); ?>)" class="col fas fa-trash"></i>
                                    </form>
                                </div></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
    </div>

</div>

<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page specific script -->
<script>
    $(function () {
        $("#example1").DataTable({
            "lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
            "order": [[ 0, "desc" ]],
            "responsive": true, "lengthChange": true, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    function confirmDelete(itemId) {
        if (confirm('Are you sure you want to delete this?')) {
            document.getElementById('delete-form-' + itemId).submit();
        }
    }
</script>
</body>
</html>
