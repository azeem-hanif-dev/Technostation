<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<style>
    /* Style the dialogue box */
    #dialogue {
        display: none;
        position: relative;
        z-index: 1;
        padding-top: 100px;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0, 0, 0, 0.4);
    }
    /* Style the dialogue box content */
    #dialogue-content {
        background-color: #fefefe;
        margin: auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
    }
    /* Style the input fields */
    .input_dialogue {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        box-sizing: border-box;
        border: 2px solid #ccc;
        border-radius: 4px;
    }
    /* Style the submit button */
    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 12px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        float: right;
    }
    /* Style the cancel button */
    .cancel-button {
        background-color: #f44336;
        color: white;
        padding: 12px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        float: right;
        margin-right: 10px;
    }
    /* Clear floats */
    .clearfix::after {
        content: "";
        clear: both;
        display: table;
    }
</style>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <div class="content-wrapper">
        <?php if(session('message')): ?>
            <div class="alert alert-warning">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
        <div class="modal fade" id="exampleModal" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <h2 style="margin: 10px"><?php echo e(__('Staffing_Company/Project_Planning/p_index.add_project')); ?></h2>
                    <form method="POST" action="<?php echo e(route('project_plannings.store')); ?>">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" class="input_dialogue" value="<?php echo e($date); ?>" name="planning_date">
                        <input type="hidden" class="input_dialogue" value="<?php echo e($id); ?>" name="planning_project_id">

                        <label style="margin: 10px" for="project"><?php echo e(__('Staffing_Company/Project_Planning/p_index.select_project')); ?></label>
                        <select class="js-example-basic-single form-control " style="width:100% ; height: 100%" name="project_id">
                            <option value="">Select Project</option>
                            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($project->id); ?>"><?php echo e($project->name ?? ''); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Create</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="modal fade" id="duplicateModal" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <h2 style="margin: 10px">Select Date to copy</h2>
                    <form method="POST" action="<?php echo e(route('copy-project-planning', $id)); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="date" class="input_dialogue" name="planning_date">
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Copy</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="card-header">
            <h3 class="float-left"><?php echo e($date); ?> || Week No. <?php echo e($week_no); ?> || <?php echo e($day); ?> </h3>
            <button type="button" class="btn btn-primary float-right ml-2" data-toggle="modal" data-target="#exampleModal">+ <?php echo e(__('Staffing_Company/Project_Planning/p_index.add_project')); ?></button>
            <a href="<?php echo e(route('project_plannings.index')); ?>">
                <button type="button" class="btn btn-danger float-right">Cancel</button>
            </a>
            <button type="button" class="btn btn-warning float-right mr-2" data-toggle="modal" data-target="#duplicateModal">Duplicate</button>
            <a href="<?php echo e(route('project-planning-pdf',$id)); ?>">
                <button type="button" class="btn btn-success mr-2 float-right">PDF</button>
            </a>
        </div>
        <div class="card">
            <?php $__currentLoopData = $planning_projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planning_project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                            <!-- /.card-header -->
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h3><?php echo e($planning_project->name); ?> (<?php echo e($planning_project->customer->name); ?>) - <?php echo e($planning_project->address); ?></h3>
                                    </div>
                                   <div class="col-md-2">
                                       <form method="POST" action="<?php echo e(route('remove-planning-project', ['date' => $date, 'project_id' => $planning_project->id])); ?>" id="delete-form-<?php echo e($planning_project->id); ?>">
                                           <?php echo csrf_field(); ?>
                                           <?php echo method_field('Delete'); ?>
                                           <button type="button" onclick="confirmDelete(<?php echo e($planning_project->id); ?>)" class="btn btn-danger float-right">- Remove Project</button>
                                       </form>
                                   </div>
                                    <div class="col-md-2">
                                        <a href="<?php echo e(route('employee_plannings.create', ['planning_id' => $id,'date' => $date, 'project_id' => $planning_project->id])); ?>"><button class="btn btn-success float-right"><?php echo e(__('Staffing_Company/Project_Planning/p_index.new_staff')); ?></button></a>
                                    </div>
                                </div>
                                <table class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th><?php echo e(__('Staffing_Company/common.staff')); ?></th>
                                        <th><?php echo e(__('Staffing_Company/common.directing')); ?></th>
                                        <th><?php echo e(__('Staffing_Company/common.accepting')); ?></th>
                                        <th><?php echo e(__('Staffing_Company/common.e_function')); ?></th>

                                        <th><?php echo e(__('Staffing_Company/common.working_hours')); ?></th>
                                        <th><?php echo e(__('Staffing_Company/common.approval')); ?></th>
                                        <th><?php echo e(__('Staffing_Company/common.option')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $employee_plannings->where('project_id', $planning_project->id)->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee_planning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <?php
                                                $personnel = \App\Models\StaffingCompany\Personnel::find($employee_planning->employee_id);
                                            ?>
                                            <td><?php echo e($employee_planning->employee_id); ?></td>
                                            <?php if(_isEmployeeInMoreThanOneProject($employee_planning->employee_id, $employee_planning->projectPlanning->date)): ?>
                                                <td style="background-color: #00a65a; color: white"><?php echo e($personnel->first_name ?? ''); ?> <?php echo e($personnel->last_name ?? ''); ?></td>
                                            <?php else: ?>
                                                <td><?php echo e($personnel->first_name ?? ''); ?> <?php echo e($personnel->last_name ?? ''); ?></td>
                                            <?php endif; ?>
                                            <td><?php if($employee_planning->status == 1): ?>
                                                    Yes
                                                <?php else: ?>
                                                    No
                                                <?php endif; ?></td>
                                            <td><?php if($employee_planning->status == 2): ?>
                                                    Yes
                                                <?php else: ?>
                                                    No
                                                <?php endif; ?></td>
                                            <td><?php echo e(\App\Models\StaffingCompany\EmployeeFunction::find($employee_planning->geschikt)->name ?? ''); ?></td>

                                            <td>0.00</td>
                                            <td>No</td>
                                            <td><div class="row">
                                                    
                                                    
                                                    
                                                    <a href="<?php echo e(route('employee_plannings.edit', $employee_planning->id)); ?>">
                                                        <i style="color: green;" class="col far fa-edit"></i>
                                                    </a>
                                                    <form method="POST" action="<?php echo e(route('employee_plannings.destroy', $employee_planning->id)); ?>?day_no=<?php echo e($day_no); ?>" id="delete-form-<?php echo e($employee_planning->id); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('Delete'); ?>
                                                        <i style="color: red" type="button" onclick="confirmDelete(<?php echo e($employee_planning->id); ?>)" class="col fas fa-trash"></i>
                                                    </form>
                                                </div></td>
                                        </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</div>

<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page specific script -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script>
    $(function () {
        $("#example1").DataTable({
            "lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
            "order": [[ 0, "desc" ]],
            "responsive": true, "lengthChange": true, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    function confirmDelete(itemId) {
        if (confirm('Are you sure you want to delete this?')) {
            document.getElementById('delete-form-' + itemId).submit();
        }
    }

</script>
<script type="text/javascript">
    $(document).ready(function() {
        $(".js-example-basic-single").select2();
    });
</script>
</body>
</html>
