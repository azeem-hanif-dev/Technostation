<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
        <div id="myapp">
            <update-week-state
                :id="<?php echo e(json_encode($id)); ?>"
                :project_id="<?php echo e(json_encode($project_id)); ?>"
                :projects="<?php echo e(json_encode($projects)); ?>"
                :personnels="<?php echo e(json_encode($personnels)); ?>"
                :wages="<?php echo e(json_encode($comments)); ?>"
                :translations="<?php echo e(json_encode($translations)); ?>"
            >
            </update-week-state>
        </div>
    </div>

</div>
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
