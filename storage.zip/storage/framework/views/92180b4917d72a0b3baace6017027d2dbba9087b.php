<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="content-wrapper">
        <div class="card">
            <h3 class="ml-3 mt-2">Employment Agency Overview</h3>
            <div style="margin-top: 10px;" class="card-header">
                <div class="row">
                    <div class="col-md-8">
                        <form method="POST" action="<?php echo e(route('search-employee-agency-overview')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <label class="ml-5 mr-2 mt-2"><?php echo e(__('Staffing_Company/Week_State/w_index.year')); ?></label>
                                <select style="width: 100px;" class="form-control" name="year">
                                    <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label  class="ml-2 mr-2 mt-2"><?php echo e(__('Staffing_Company/common.week_no')); ?>.</label>
                                <select style="width: 70px;" class="form-control" name="week_no">
                                    <?php for($i = 1; $i <= 52; $i++): ?>
                                        <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                                <button type="submit" class="btn btn-primary btn-sm ml-2"><?php echo e(__('Staffing_Company/Week_State/w_index.search')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th><?php echo e(__('Staffing_Company/common.name')); ?></th>
                        <th>Worked Hours</th>
                        <th>Cost</th>
                        <th>Dispatch Date</th>
                        <th>Receive Date</th>
                        <th>Invoice Date</th>
                        <th>Status</th>
                        <th>Done</th>
                        <th>Options</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $agency_overviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($agency->name ?? ''); ?></td>
                            <?php
                                $detail = $agency_overviews_details->firstWhere('employ_agency_id', $agency->id);
                            ?>

                            <?php if($detail): ?>
                                <td><?php echo e($detail->worked_hours); ?></td>
                                <td><?php echo e($detail->cost); ?></td>
                                <td><?php echo e($detail->dispatch_date); ?></td>
                                <td><?php echo e($detail->receive_date); ?></td>
                                <td><?php echo e($detail->invoice_date); ?></td>
                                <td><?php echo e($detail->status ? 'Open' : 'Closed'); ?></td>
                                <td><?php echo e($detail->completed ? 'Open' : 'Closed'); ?></td>
                            <?php else: ?>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            <?php endif; ?>
                            <?php
                                $agency = App\Models\EmployAgency::find($agency->id);
                                $staff_ids = $agency->personnels()->pluck('id');
                                $week_state_ids = App\Models\StaffingCompany\SfWeekCard::whereIn('personnel_id', $staff_ids)->where('week_no', $week_no)->pluck('week_state_id')->unique()->toArray();
                                $week_state_ids = implode(', ', $week_state_ids);
                            ?>
                            <td>
                                <div class="row">
                                    <a href="<?php echo e(url('/employment-agency/'.$agency->id.'/week-state/'.$week_no)); ?>">
                                        <i style="color: green;" class="col fa fa-search"></i>
                                    </a>
                                    <a href="<?php echo e(url('employment-agency-overview/'.$week_state_ids.'/create/'.$agency->id.'/week-no/'.$week_no)); ?>">
                                        <i style="color: green;" class="col fa fa-edit"></i>
                                    </a>
                                    <a href="<?php echo e(route('week-state-pdf', ['week_state_ids' => $week_state_ids, 'week_no' => $week_no, 'agency_id' => $agency->id])); ?>">
                                        <i style="color: red;" class="col fa fa-file-pdf"></i>
                                    </a>
                                    <a href="<?php echo e(route('week-state-email', ['week_state_ids' => $week_state_ids, 'week_no' => $week_no, 'agency_overview_id' => $agency->id])); ?>">
                                        <i style="color: green;" class="col fa fa-envelope"></i>
                                    </a>
                                </div></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
    </div>

</div>

<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page specific script -->
<script>
    $(function () {
        $("#example1").DataTable({
            "lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
            "order": [[ 0, "desc" ]],
            "responsive": true, "lengthChange": true, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    function confirmDelete(itemId) {
        if (confirm('Are you sure you want to delete this?')) {
            document.getElementById('delete-form-' + itemId).submit();
        }
    }
</script>
</body>
</html>
