<!DOCTYPE html>
<html lang="en">

<head>
  <?php echo $__env->make('landing_page.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->yieldContent('outer_css'); ?>
</head>

<body id="page-top">

  <!-- Navigation -->
  
  <?php echo $__env->make('landing_page.partials._services', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('landing_page.partials._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- Header -->


  <!-- Bootstrap core JavaScript -->

</body>

</html>
