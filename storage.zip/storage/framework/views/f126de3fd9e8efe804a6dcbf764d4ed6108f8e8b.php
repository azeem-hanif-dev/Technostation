<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
        <div id="myapp">
            <update-personnel
                :agencies="<?php echo e(json_encode($agencies)); ?>"
                :personnel_functions="<?php echo e(json_encode($personnel_functions)); ?>"
                :e_functions="<?php echo e(json_encode($e_functions)); ?>"
                :staff_types="<?php echo e(json_encode($staff_types)); ?>"
                :translations="<?php echo e(json_encode($translations)); ?>"
                :nationalities="<?php echo e(json_encode($nationalities)); ?>"
                :common="<?php echo e(json_encode($common)); ?>"
                :token="<?php echo e(json_encode($token)); ?>"
                :personnel_function_names="<?php echo e(json_encode($personnel_function_names)); ?>"
                :personnel="<?php echo e(json_encode($personnel)); ?>">
            </update-personnel>
        </div>
    </div>

</div>
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
