<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="content-wrapper">
        <div class="card">
            <div style="margin-top: 10px;" class="card-header">
                <h3><?php echo e(__('Staffing_Company/Request_Staff/r_index.request_staff')); ?></h3>
                <a href="<?php echo e(route('request_personnels.create')); ?>">
                    <button class="btn btn-success float-right"><?php echo e(__('Staffing_Company/Request_Staff/r_index.new')); ?></button>
                </a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th><?php echo e(__('Staffing_Company/Request_Staff/r_index.application_no')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.project')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Request_Staff/r_index.submission_date')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Request_Staff/crud.starting_date_time')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Request_Staff/r_index.no_of_person')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Request_Staff/r_index.how_many_days')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Request_Staff/r_index.activities')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.done')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $request_personnels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request_personnel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($request_personnel->id); ?></td>
                            <td><?php echo e($request_personnel->application_no); ?></td>
                            <td><?php echo e($request_personnel->project->name ?? ''); ?></td>
                            <td><?php echo e($request_personnel->application_date_time); ?></td>
                            <td><?php echo e($request_personnel->starting_date_time); ?></td>
                            <td><?php echo e($request_personnel->no_of_people); ?></td>
                            <td><?php echo e($request_personnel->days); ?></td>
                            <td><?php echo e($request_personnel->employeeFunction->name ?? ''); ?></td>
                            <td style="color: <?php echo e($request_personnel->complete ? 'green' : 'red'); ?>;"><?php echo e($request_personnel->complete ? 'Done' : 'Open'); ?></td>
                            <td><div class="row">
                                    <a href="<?php echo e(route('request-personnel.view', $request_personnel->id)); ?>">
                                        <i style="color: green;" class="col fa fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('request_personnels.edit', $request_personnel->id)); ?>">
                                        <i style="color: green;" class="col far fa-edit"></i>
                                    </a>
                                    <a href="<?php echo e(route('request-personnel-pdf', $request_personnel->id)); ?>">
                                        <i style="color: green;" class="col far fa-file-pdf"></i>
                                    </a>
                                   <form method="POST" action="<?php echo e(route('request_personnels.destroy', $request_personnel->id)); ?>" id="delete-form-<?php echo e($request_personnel->id); ?>">
                                       <?php echo csrf_field(); ?>
                                       <?php echo method_field('Delete'); ?>
                                       <i style="color: red" type="button" onclick="confirmDelete(<?php echo e($request_personnel->id); ?>)" class="col fas fa-trash"></i>
                                   </form>
                                </div></td>
                        </tr>
                        <div class="modal fade" id="modal-danger">
                            <div class="modal-dialog">
                                <div class="modal-content bg-danger">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Delete Customer</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <p>Are you sure you want to delete this customer?</p>
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                        <form method="POST" action="<?php echo e(route('request_personnels.destroy', $request_personnel->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('Delete'); ?>
                                            <button type="submit" class="float-left btn btn-outline-light">Delete</button>
                                        </form>
                                        <button type="button" class="btn btn-outline-light" data-dismiss="modal">Cancel</button>
                                    </div>
                                </div>
                                <!-- /.modal-content -->
                            </div>
                            <!-- /.modal-dialog -->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
    </div>

</div>

<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page specific script -->
<script>
    $(function () {
        $("#example1").DataTable({
            "lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
            "order": [[ 0, "desc" ]],
            "responsive": true, "lengthChange": true, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    function confirmDelete(itemId) {
        if (confirm('Are you sure you want to delete this?')) {
            document.getElementById('delete-form-' + itemId).submit();
        }
    }
</script>
</body>
</html>
