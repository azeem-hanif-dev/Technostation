<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="card col-md-11">
                <div class="card-header row">
                    <div class="col-md-6">
                        <h4>Customer</h4>
                    </div>
                    <div class="col-md-6">
                        <a href="<?php echo e(url('employment-agencies')); ?>"
                           class="btn btn-success btn-xs float-right"
                        > <?php echo e(__('Staffing_Company/staff/create.back')); ?> </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <p><strong><?php echo e(__('Staffing_Company/Customer/crud.name')); ?>:</strong> <?php echo e($agency->name); ?></p>
                            <p><strong><?php echo e(__('Staffing_Company/Customer/crud.email')); ?>:</strong> <?php echo e($agency->email); ?></p>
                            <p><strong><?php echo e(__('Staffing_Company/Customer/crud.contact')); ?>:</strong> <?php echo e($agency->contact_person); ?></p>
                            <p><strong><?php echo e(__('Staffing_Company/Customer/crud.phone')); ?>:</strong> <?php echo e(_formatPhoneNumber($agency->phone)); ?></p>
                            <p><strong>URL:</strong> <?php echo e($agency->url); ?></p>
                        </div>
                        <div class="col-md-4">
                            <p><strong><?php echo e(__('Staffing_Company/Customer/crud.address')); ?>:</strong> <?php echo e($agency->address); ?></p>
                            <p><strong><?php echo e(__('Staffing_Company/Customer/crud.city')); ?>:</strong> <?php echo e($agency->city); ?></p>
                            <p><strong><?php echo e(__('Staffing_Company/Customer/crud.country')); ?>:</strong> <?php echo e($agency->country); ?></p>
                            <p><strong>Postcode:</strong> <?php echo e($agency->zipcode); ?></p>
                        </div>
                        <div class="col-md-12">
                            <p><strong>Notes:</strong> <?php echo e($agency->notes); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-11">
                <table class="table table-bordered table-striped ml-2">
                    <thead>
                    <tr>
                        <th>Document Type</th>
                        <th>Document Expiry</th>
                        <th>File</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if($agency->documents): ?>
                        <?php $__currentLoopData = $agency->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($document->type); ?></td>
                                <td><?php echo e($document->expiry_date); ?></td>
                                <td><a href="<?php echo e(asset('storage/app/public/employment_agency_docs/'.$document->file)); ?>" target="_blank">Open File</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <td>
                            Not found
                        </td>
                        <td>
                            Not found
                        </td>
                        <td>
                            Not found
                        </td>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
