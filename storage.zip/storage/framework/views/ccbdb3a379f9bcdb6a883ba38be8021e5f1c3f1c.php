<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('home')); ?>" class="brand-link">
              <img src="<?php echo e(asset('staffing_company/dist/img/staffing_company_logo.png')); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">Staffing Companies</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">

            </div>
            <div class="info">
                <a href="<?php echo e(route('home')); ?>" class="d-block"><?php echo e(_user()->name ?? ""); ?></a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <!-- Add icons to the links using the .nav-icon class
                     with font-awesome or any other icon font library -->
                <li class="nav-item">
                      <a href="<?php echo e(route('home')); ?>" class="nav-link">
                          <i class="nav-icon fa fa-tachometer-alt" aria-hidden="true"></i>
                             <p><?php echo e(__('Staffing_Company/side_bar.dashboard')); ?></p>
                      </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('user-profile')); ?>" class="nav-link">
                        <i class="nav-icon fa fa-user" aria-hidden="true"></i>
                        <p><?php echo e(__('Staffing_Company/side_bar.user_profile')); ?></p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-users"></i>
                        <p>
                            <?php echo e(__('Staffing_Company/side_bar.staff_function')); ?>

                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <?php if(_isUserAdmin() || _isUserRightToSee(1)): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('personnels.index')); ?>" class="nav-link">
                                    <i class="nav-icon fa fa-user"></i>
                                    <p><?php echo e(__('Staffing_Company/side_bar.staff')); ?></p>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if(_isUserAdmin() || _isUserRightToSee(2)): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('employee_functions.index')); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-user"></i>
                                        <p><?php echo e(__('Staffing_Company/side_bar.staff_function')); ?></p>
                                    </a>
                                </li>
                        <?php endif; ?>
                    </ul>
                </li>

                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-users"></i>
                        <p>
                            <?php echo e(__('Staffing_Company/side_bar.customer_heading')); ?>

                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <?php if(_isUserAdmin() || _isUserRightToSee(3)): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('customers.index')); ?>" class="nav-link">
                                    <i class="nav-icon fas fa-user"></i>
                                    <p><?php echo e(__('Staffing_Company/side_bar.customer')); ?></p>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if(_isUserAdmin() || _isUserRightToSee(4)): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('departments.index')); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-industry" aria-hidden="true"></i>
                                        <p><?php echo e(__('Staffing_Company/side_bar.department')); ?></p>
                                    </a>
                                </li>
                        <?php endif; ?>

                            <?php if(_isUserAdmin() || _isUserRightToSee(5)): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('staffing_projects.index')); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-briefcase" aria-hidden="true"></i>
                                        <p><?php echo e(__('Staffing_Company/side_bar.project')); ?></p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if(_isUserAdmin() || _isUserRightToSee(6)): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('project_plannings.index')); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-calendar" aria-hidden="true"></i>
                                        <p><?php echo e(__('Staffing_Company/side_bar.project_planning')); ?></p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if(_isUserAdmin() || _isUserRightToSee(7)): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('contacts.index')); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-phone-square" aria-hidden="true"></i>
                                        <p><?php echo e(__('Staffing_Company/side_bar.contact')); ?></p>
                                    </a>
                                </li>
                            <?php endif; ?>
                    </ul>
                </li>

                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-users"></i>
                        <p>
                            <?php echo e(__('Staffing_Company/side_bar.mgmt_functions')); ?>

                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <?php if(_isUserAdmin() || _isUserRightToSee(8)): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('request_personnels.index')); ?>" class="nav-link">
                                    <i class="nav-icon fa fa-user"></i>
                                    <p><?php echo e(__('Staffing_Company/side_bar.request_staff')); ?></p>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if(_isUserAdmin() || _isUserRightToSee(9)): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('container-supplier.index')); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-user"></i>
                                        <p><?php echo e(__('Staffing_Company/side_bar.container_supplier')); ?></p>
                                    </a>
                                </li>
                        <?php endif; ?>

                            <?php if(_isUserAdmin() || _isUserRightToSee(10)): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('order-waste-container.index')); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-user"></i>
                                        <p><?php echo e(__('Staffing_Company/side_bar.order_waste_container')); ?></p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if(_isUserAdmin() || _isUserRightToSee(11)): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('week-state.index')); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-book"></i>
                                        <p><?php echo e(__('Staffing_Company/side_bar.week_statement')); ?></p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('week-weekly-state')); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-book"></i>
                                        <p><?php echo e(__('Staffing_Company/side_bar.week_weekly_statement')); ?></p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if(_isUserAdmin() || _isUserRightToSee(12)): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('comments.index')); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-comment"></i>
                                        <p><?php echo e(__('Staffing_Company/side_bar.comment')); ?></p>
                                    </a>
                                </li>
                            <?php endif; ?>
                    </ul>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('employment-agency-overview.index')); ?>" class="nav-link">
                        <p style="font-size: 16px;">
                            <i class="nav-icon fa fa-building" aria-hidden="true"></i>
                            Employment Agency Overview
                        </p>
                    </a>
                </li>
                <?php if(_isUserAdmin() || _isUserRightToSee(13)): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('employment-agencies.index')); ?>" class="nav-link">
                            <p style="font-size: 16px;">
                                <i class="nav-icon fa fa-building" aria-hidden="true"></i>
                                <?php echo e(__('Staffing_Company/side_bar.employment_agency')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(_isUserAdmin() || _isUserRightToSee(14)): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('user-options.index')); ?>" class="nav-link">
                            <i class="nav-icon fas fa-users"></i>
                            <p style="font-size: 16px;">
                                Rights Module
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
