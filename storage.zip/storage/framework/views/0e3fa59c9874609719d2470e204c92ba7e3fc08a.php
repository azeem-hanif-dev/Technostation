
<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="card col-md-11">
                <div class="card-header row">
                    <div class="col-md-6">
                        <h4>Weekly State</h4>
                    </div>
                    <div class="col-md-6">
                        <a href="<?php echo e(route('week-state.index')); ?>"
                           class="btn btn-success btn-xs float-right"
                        > <?php echo e(__('Staffing_Company/Week_State/crud.back')); ?> </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <table class="table table-bordered sort">
                            <thead>
                            <tr>
                                <th><?php echo e(__('Staffing_Company/Week_State/crud.staff')); ?></th>

                                <th><?php echo e(__('Staffing_Company/Week_State/crud.mon')); ?></th>

                                <th><?php echo e(__('Staffing_Company/Week_State/crud.tue')); ?></th>

                                <th><?php echo e(__('Staffing_Company/Week_State/crud.wed')); ?></th>

                                <th><?php echo e(__('Staffing_Company/Week_State/crud.thu')); ?></th>

                                <th><?php echo e(__('Staffing_Company/Week_State/crud.fri')); ?></th>

                                <th><?php echo e(__('Staffing_Company/Week_State/crud.sat')); ?></th>

                                <th><?php echo e(__('Staffing_Company/Week_State/crud.sun')); ?></th>

                                <th>+</th>

                                <th><?php echo e(__('Staffing_Company/Week_State/crud.customer')); ?></th>

                                <th><?php echo e(__('Staffing_Company/Week_State/crud.cost')); ?></th>

                                <th style="width: 10px;"><?php echo e(__('Staffing_Company/Week_State/crud.directing')); ?></th>

                                <th><?php echo e(__('Staffing_Company/Week_State/crud.comments')); ?></th>
                            </tr>

                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $week_state->weekCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wee_card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><p>
                                        <?php if($wee_card->personnel): ?>
                                            <?php echo e($wee_card->personnel->first_name); ?>

                                        <?php endif; ?>
                                    </p>
                                </td>
                                <td><p>
                                        <?php echo e($wee_card->hours_1); ?>

                                    </p>
                                </td>

                                <td><p>
                                        <?php echo e($wee_card->hours_2); ?>

                                    </p>
                                </td>

                                <td><p>
                                        <?php echo e($wee_card->hours_3); ?>

                                    </p>
                                </td>

                                <td><p>
                                        <?php echo e($wee_card->hours_4); ?>

                                    </p>
                                </td>

                                <td><p>
                                        <?php echo e($wee_card->hours_5); ?>

                                    </p>
                                </td>

                                <td><p>
                                        <?php echo e($wee_card->hours_6); ?>

                                    </p>
                                </td>

                                <td><p>
                                        <?php echo e($wee_card->hours_7); ?>

                                    </p>
                                </td>

                                <td>
                                    <p><?php echo e($wee_card->total_hours); ?></p>
                                </td>

                                <td><p><?php echo e($wee_card->rate); ?></p></td>

                                <td><p><?php echo e($wee_card->cost); ?></p></td>
                                <td>
                                    <?php if($wee_card->directing): ?>
                                        Yes
                                    <?php else: ?>
                                        No
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <p><?php echo e($wee_card->wage); ?></p>
                                </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong><?php echo e(__('Staffing_Company/Week_State/crud.week_no')); ?>:</strong> <?php echo e($week_state->week_no); ?></p>
                            <p><strong><?php echo e(__('Staffing_Company/Week_State/crud.invoice_no')); ?>:</strong> <?php echo e($week_state->invoice_no); ?></p>
                            <p><strong><?php echo e(__('Staffing_Company/Week_State/crud.approved')); ?>:
                            <?php if($week_state->approved): ?>
                                </strong>Yes</p>
                            <?php else: ?>
                                </strong>No</p>
                            <?php endif; ?>
                            <p><strong><?php echo e(__('Staffing_Company/Week_State/crud.worksheet')); ?>:
                                    <?php if($week_state->via_worksheet): ?>
                                </strong>Yes</p>
                            <?php else: ?>
                                </strong>No</p>
                            <?php endif; ?>
                            <p><strong><?php echo e(__('Staffing_Company/Week_State/crud.delay_date')); ?>:</strong> <?php echo e($week_state->delay_date); ?></p>
                            <p><strong><?php echo e(__('Staffing_Company/Week_State/crud.received_date')); ?>:</strong> <?php echo e($week_state->receive_date); ?></p>
                            <p><strong><?php echo e(__('Staffing_Company/Week_State/crud.invoice_date')); ?>:</strong> <?php echo e($week_state->invoice_date); ?></p>
                            <p><strong><?php echo e(__('Staffing_Company/Week_State/crud.comments')); ?>:</strong> <?php echo e($week_state->comments); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong><?php echo e(__('Staffing_Company/Week_State/crud.customer')); ?>:</strong> <?php echo e($project->customer->name); ?></p>
                            <p><strong><?php echo e(__('Staffing_Company/Week_State/crud.department')); ?>:</strong> <?php echo e($project->department->name); ?></p>
                            <p><strong>Performer:</strong> <?php echo e($project->projectPerformer ? $project->projectPerformer->first_name : ''); ?></p>
                            <p><strong><?php echo e(__('Staffing_Company/Week_State/crud.notes')); ?>:</strong><?php echo e($project->notes); ?></p>
                            <p><strong><?php echo e(__('Staffing_Company/Week_State/crud.approval')); ?>:</strong><?php echo e($project->approval); ?></p>
                            <p><strong><?php echo e(__('Staffing_Company/Week_State/crud.internal')); ?>:</strong> <?php echo e($week_state->internal_notes); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-11">
                <table class="table table-bordered table-striped ml-2">
                    <thead>
                    <tr>
                        <th>Document Type</th>
                        <th>Document Expiry</th>
                        <th>File</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if($week_state->documents): ?>
                        <?php $__currentLoopData = $week_state->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($document->type); ?></td>
                                <td><?php echo e($document->expiry_date); ?></td>
                                <td><a href="<?php echo e(asset('storage/app/public/week_state_docs/'.$document->file)); ?>" target="_blank">Open File</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <td>
                            Not found
                        </td>
                        <td>
                            Not found
                        </td>
                        <td>
                            Not found
                        </td>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
