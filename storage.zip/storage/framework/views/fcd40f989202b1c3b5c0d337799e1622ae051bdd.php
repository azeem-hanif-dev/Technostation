<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
        <div id="myapp">
            <create-request-personnel
                :current_date_time="<?php echo e(json_encode(_currentDateTime())); ?>"
                :e_functions="<?php echo e(json_encode($e_functions)); ?>"
                :projects="<?php echo e(json_encode($projects)); ?>"
                :translations="<?php echo e(json_encode($translations)); ?>"
                :common="<?php echo e(json_encode($common)); ?>"
            >
            </create-request-personnel>
        </div>
    </div>

</div>
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
