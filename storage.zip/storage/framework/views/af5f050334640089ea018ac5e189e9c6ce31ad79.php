<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="content-wrapper">
        <div class="card">
            <div style="margin-top: 10px;" class="card-header">
                <h3><?php echo e(__('Staffing_Company/Project/p_index.project')); ?></h3>
                <a href="<?php echo e(route('staffing_projects.create')); ?>">
                    <button class="btn btn-success float-right"><?php echo e(__('Staffing_Company/Project/p_index.add_new')); ?></button>
                </a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th><?php echo e(__('Staffing_Company/Project/p_index.name')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Project/p_index.department')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Project/p_index.address')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Project/p_index.city')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Project/p_index.status')); ?></th>
                        <th><?php echo e(__('Staffing_Company/Project/p_index.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($project->id); ?></td>
                            <td><?php echo e($project->name ?? ''); ?></td>
                            <td><?php echo e($project->department->name ?? ''); ?></td>
                            <td><?php echo e($project->address ?? ''); ?></td>
                            <td><?php echo e($project->city ?? ''); ?></td>
                            <td><?php if($project->active): ?>
                                    <span style="color: white; padding: 3px; font-size: 12px; background-color: green"><?php echo e(__('Staffing_Company/common.active')); ?></span>
                                <?php else: ?>
                                    <span style="color: white; padding: 3px; font-size: 12px; background-color: red"><?php echo e(__('Staffing_Company/common.inactive')); ?></span>
                                <?php endif; ?></td>
                            <td><div class="row">
                                    <a href="<?php echo e(route('staffing-project.view', $project->id)); ?>">
                                        <i style="color: green;" class="col fa fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('staffing_projects.edit', $project->id)); ?>">
                                        <i style="color: green;" class="col far fa-edit"></i>
                                    </a>
                                   <form method="POST" action="<?php echo e(route('staffing_projects.destroy', $project->id)); ?>" id="delete-form-<?php echo e($project->id); ?>">
                                       <?php echo csrf_field(); ?>
                                       <?php echo method_field('Delete'); ?>
                                       <i style="color: red" type="button" onclick="confirmDelete(<?php echo e($project->id); ?>)" class="col fas fa-trash"></i>
                                   </form>
                                </div></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
    </div>

</div>

<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page specific script -->
<script>
    $(function () {
        $("#example1").DataTable({
            "lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
            "order": [[ 0, "desc" ]],
            "responsive": true, "lengthChange": true, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    function confirmDelete(itemId) {
        if (confirm('Are you sure you want to delete this?')) {
            document.getElementById('delete-form-' + itemId).submit();
        }
    }
</script>
</body>
</html>
