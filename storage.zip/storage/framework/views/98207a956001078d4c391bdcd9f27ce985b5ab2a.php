<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('StaffingCompany.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <?php echo $__env->make('StaffingCompany.partials._navBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('StaffingCompany.partials._sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="content-wrapper">
        <div class="card">
            <div style="margin-top: 10px;" class="card-header">
                <h3>Contact <?php echo e(__('Staffing_Company/common.management')); ?></h3>
                <a href="<?php echo e(route('contacts.create')); ?>">
                    <button class="btn btn-success float-right"><?php echo e(__('Staffing_Company/common.add_new')); ?> Contact</button>
                </a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>Sr.#</th>
                        <th><?php echo e(__('Staffing_Company/common.first_name')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.last_name')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.phone')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.email')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.department')); ?></th>
                        <th><?php echo e(__('Staffing_Company/staff/s_index.status')); ?></th>
                        <th><?php echo e(__('Staffing_Company/common.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($contact->first_name ?? ''); ?></td>
                            <td><?php echo e($contact->last_name ?? ''); ?></td>
                            <td><?php echo e($contact->mobile ?? ''); ?></td>
                            <td><?php echo e($contact->email ?? ''); ?></td>
                            <td><?php echo e($contact->department->name ?? ''); ?></td>
                            <td><?php if($contact->active): ?>
                                <span style="color: white; padding: 3px; font-size: 12px; background-color: green"><?php echo e(__('Staffing_Company/staff/s_index.active')); ?></span>
                            <?php else: ?>
                                <span style="color: white; padding: 3px; font-size: 12px; background-color: red"><?php echo e(__('Staffing_Company/staff/s_index.inactive')); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><div class="row">
                                    <a href="<?php echo e(route('contacts.show', $contact->id)); ?>">
                                        <i style="color: green;" class="col fa fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('contacts.edit', $contact->id)); ?>">
                                        <i style="color: green;" class="col far fa-edit"></i>
                                    </a>





                                </div></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
    </div>

</div>

<?php echo $__env->make('StaffingCompany.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $(function () {
        $("#example1").DataTable({
            "lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
            "order": [[ 0, "desc" ]],
            "responsive": true, "lengthChange": true, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    function confirmDelete(itemId) {
        if (confirm('Are you sure you want to delete this?')) {
            document.getElementById('delete-form-' + itemId).submit();
        }
    }
</script>
</body>
</html>
